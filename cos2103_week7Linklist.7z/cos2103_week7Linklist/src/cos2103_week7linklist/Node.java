/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cos2103_week7linklist;

/**
 *
 * @author PC
 */
public class Node {
    Object INFOR;
    Node LINK=null;    
}

